Installation steps:

	0. This assumes you have a Telegram account and a way to 
	   execute python3 in your machine. Easy.

	1. Get your Telegram development API credentials. Go to
	   https://core.telegram.org/api/obtaining_api_id and follow
	   the instructions to get your api_id and api_hash.
	
	2. Extract the files and paste your api_id and api_hash in 
           the config.ini file. Fill also the configs for your 
           username and phone number.
	
	3. Move the extracted files into C:/Program Files/domainer-win-cli/ 

	4. Install the python3 library 'telethon'
	
	5. Execute the program manually for the first time
	   from  within C:/Program Files/domainer-win-cli/ in
	   a command interpreter and fill in the data requested. 
	   After successfull execution, several lines of text will 
	   appear, containing hostnames and IPs. Something like this:
	
			# Domainer line
			99.99.99.99   oyster.kl

			# Auto-updated by klnet
			88.88.88.88   glaucus.kl		
	
	That's a success!
	
	A file named domainer-cli.session will be automatically created.
	Do NOT share this file! Treat this file as securely as you would
	treat your Telegram password. 
	
	6. It is recomended that the script runs periodically, at least
	   once every boot. That configuration is up to you. You 
	   can always run it manually if needed. 
	
