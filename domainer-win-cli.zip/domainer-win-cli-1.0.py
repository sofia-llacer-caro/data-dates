#!/usr/bin/env python3
import configparser
import subprocess
import time
import urllib.request
import platform

from telethon import TelegramClient

# Reading Configs
config = configparser.ConfigParser()
config.read("C:/Program Files/domainer-win-cli/config.ini")

# Setting configuration values
api_id = config['Telegram']['api_id']
api_hash = config['Telegram']['api_hash']
klnet_chat = ['Telegram']['klnet_chat']

api_hash = str(api_hash)
				# domainer-cli
domainer_client = TelegramClient('C:/Program Files/domainer-win-cli/domainer-cli.session', api_id, api_hash)

# Global variable hehe
message = 0

def online(host='http://ifconfig.me'):
    try:
        urllib.request.urlopen(host) #Python 3.x
        return True
    except:
        return False

async def get_msg():

	# Gets the last message
	async for message in domainer_client.iter_messages(domainer_chat, limit=1):
		# IP is recorded into global variable
		global message
		message = message.text

	# Deletes message number 4 (oldest)
	message = await domainer_client.get_messages(domainer_chat, limit=4)
	if len(message) > 100:

		msg = message[100]
		await domainer_client.delete_messages(domainer_chat, msg.id)

def main():

	etc_hosts = "C:/Windows/System32/drivers/etc/hosts"

	while not online():
		time.sleep(2)

	# Start the client and get the IP
	domainer_client.start()
	with domainer_client:
		domainer_client.loop.run_until_complete(get_msg())

	# Stringify message and sed attributes to modify /etc/hosts
	stringmessage = str(message)
	print(stringmessage)

	# Cleaner way but for linux :(
	#sedstr = str("/oyster.kl/c"+stringmessage+" oyster.kl")
	#subprocess.call(['sed', '-i', sedstr, etc_hosts])
	
	# The hosts file will be overwritten
	file = open(etc_hosts, "w")
	file.write(stringmessage)
	file.close()

if __name__ == "__main__":
   main()
